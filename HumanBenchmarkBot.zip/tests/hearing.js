if (window.confirm("You really wanna do this?")) {
    let mainElement = document.getElementsByClassName("css-12ibl39 e19owgy77")[0];

    mainElement.click()
    mainElement.click()
}